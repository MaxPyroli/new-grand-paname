# 🚇 Grand Paname - PWA

Application Progressive Web App pour consulter les horaires de transport en Île-de-France en temps réel.

## ✨ Fonctionnalités

- 🔍 Recherche de stations en temps réel
- ⚡ Affichage des prochains départs (Métro, RER, Tramway, Bus)
- ⭐ Système de favoris (sauvegardé localement)
- 🔄 Actualisation automatique toutes les 30 secondes
- 📱 Installable sur mobile et desktop (PWA)
- 🎨 Interface moderne et responsive
- 💾 Fonctionne hors-ligne (mode cache)

## 🚀 Installation locale

### Prérequis
- Node.js 14+ installé sur votre machine

### Étapes

1. **Installer les dépendances**
```bash
npm install
```

2. **Configurer l'API**
```bash
cp .env.example .env
# Éditer .env et ajouter votre clé API IDFM
```

3. **Lancer le serveur**
```bash
npm start
```

4. **Ouvrir dans le navigateur**
```
http://localhost:3000
```

## 🌐 Déploiement

### Option 1: Vercel (Recommandé - GRATUIT)

1. Créer un compte sur [vercel.com](https://vercel.com)
2. Installer Vercel CLI:
```bash
npm install -g vercel
```

3. Déployer:
```bash
vercel
```

4. Ajouter la variable d'environnement:
   - Aller dans votre projet sur vercel.com
   - Settings → Environment Variables
   - Ajouter: `IDFM_API_KEY` = `votre_clé_api`

### Option 2: Railway (GRATUIT)

1. Créer un compte sur [railway.app](https://railway.app)
2. Créer un nouveau projet depuis GitHub
3. Ajouter la variable d'environnement `IDFM_API_KEY`
4. Railway détecte automatiquement Node.js et déploie !

### Option 3: Render (GRATUIT)

1. Créer un compte sur [render.com](https://render.com)
2. New → Web Service
3. Connecter votre repo GitHub
4. Configurer:
   - Build Command: `npm install`
   - Start Command: `npm start`
5. Ajouter la variable d'environnement `IDFM_API_KEY`

### Option 4: Heroku

1. Créer un compte sur [heroku.com](https://heroku.com)
2. Créer une app:
```bash
heroku create grand-paname
```

3. Configurer la variable d'environnement:
```bash
heroku config:set IDFM_API_KEY=votre_clé_api
```

4. Déployer:
```bash
git push heroku main
```

## 📁 Structure du projet

```
grand-paname/
├── server.js           # Backend Express (proxy API)
├── package.json        # Dépendances Node.js
├── .env.example        # Exemple de configuration
├── public/             # Frontend (PWA)
│   ├── index.html      # Application React
│   ├── manifest.json   # Manifest PWA
│   └── sw.js          # Service Worker
└── README.md          # Ce fichier
```

## 🔧 Configuration avancée

### Changer le port

Modifier dans `.env`:
```
PORT=8080
```

### Personnaliser les icônes PWA

Remplacer les fichiers dans `public/`:
- `icon-192.png` (192x192px)
- `icon-512.png` (512x512px)

## 📱 Installer l'app sur mobile

### Android (Chrome)
1. Ouvrir l'app dans Chrome
2. Menu → "Ajouter à l'écran d'accueil"

### iOS (Safari)
1. Ouvrir l'app dans Safari
2. Partager → "Sur l'écran d'accueil"

## 🐛 Dépannage

### Erreur 401 Unauthorized
→ Vérifier que votre clé API est correcte dans `.env`

### Les départs ne s'affichent pas
→ Vérifier la console du navigateur (F12)
→ S'assurer que le backend est bien lancé

### L'app ne s'installe pas
→ Vérifier que vous utilisez HTTPS (obligatoire pour les PWA)
→ En local, `localhost` fonctionne aussi

## 🤝 Contribution

N'hésitez pas à créer des issues ou des pull requests !

## 📄 Licence

MIT
