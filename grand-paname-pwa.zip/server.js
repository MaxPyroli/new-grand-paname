// server.js - Backend Node.js pour Grand Paname
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuration
const API_KEY = process.env.IDFM_API_KEY || 'rNhB9Ig3dR3W6AbHQLr5MiTiqR9vidrA';
const BASE_URL = 'https://prim.iledefrance-mobilites.fr/marketplace/v2/navitia';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Route pour rechercher des stations
app.get('/api/search', async (req, res) => {
    try {
        const query = req.query.q;
        if (!query || query.length < 2) {
            return res.json({ places: [] });
        }

        const response = await fetch(
            `${BASE_URL}/coverage/fr-idf/places?q=${encodeURIComponent(query)}`,
            {
                headers: {
                    'apiKey': API_KEY
                }
            }
        );

        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }

        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error('Search error:', error);
        res.status(500).json({ error: 'Erreur lors de la recherche' });
    }
});

// Route pour récupérer les départs d'une station
app.get('/api/departures/:stopId', async (req, res) => {
    try {
        const { stopId } = req.params;
        
        const response = await fetch(
            `${BASE_URL}/coverage/fr-idf/stop_areas/${stopId}/departures?data_freshness=realtime&count=100`,
            {
                headers: {
                    'apiKey': API_KEY
                }
            }
        );

        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }

        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error('Departures error:', error);
        res.status(500).json({ error: 'Erreur lors de la récupération des départs' });
    }
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
    console.log(`🚀 Grand Paname backend running on port ${PORT}`);
});
