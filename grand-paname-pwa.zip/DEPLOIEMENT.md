# 🚀 DÉPLOIEMENT RAPIDE - GRAND PANAME

## Le plus simple : Vercel (3 minutes) ⚡

### 1. Créer un compte Vercel
→ Aller sur https://vercel.com
→ S'inscrire avec GitHub (gratuit)

### 2. Importer le projet
→ "Add New Project"
→ Importer depuis GitHub ou uploader les fichiers

### 3. Configurer
→ Framework Preset: **Other**
→ Build Command: (laisser vide)
→ Install Command: `npm install`

### 4. Ajouter la clé API
→ Settings → Environment Variables
→ Name: `IDFM_API_KEY`
→ Value: `rNhB9Ig3dR3W6AbHQLr5MiTiqR9vidrA`
→ Add

### 5. Déployer !
→ Cliquer sur "Deploy"
→ Attendre 1-2 minutes
→ Ton app est en ligne ! 🎉

L'URL sera du type : `https://grand-paname-xxx.vercel.app`

---

## Alternative : Railway.app (aussi simple)

### 1. Créer un compte
→ https://railway.app (gratuit)

### 2. New Project
→ "Deploy from GitHub repo"
→ Ou "Empty Project" puis lier GitHub

### 3. Ajouter la variable
→ Variables → Add Variable
→ `IDFM_API_KEY` = `rNhB9Ig3dR3W6AbHQLr5MiTiqR9vidrA`

### 4. Deploy
→ Railway détecte automatiquement Node.js
→ Déploiement automatique !

---

## Test en local d'abord (recommandé)

```bash
# 1. Installer les dépendances
npm install

# 2. Créer le fichier .env
cp .env.example .env

# 3. Lancer le serveur
npm start

# 4. Ouvrir http://localhost:3000
```

---

## ⚠️ Important après déploiement

1. **Tester sur mobile** : ouvrir l'URL sur ton téléphone
2. **Installer l'app** : Chrome → Menu → "Ajouter à l'écran d'accueil"
3. **Vérifier les départs** : chercher "Chatelet" pour tester

---

## 🆘 Besoin d'aide ?

Si ça ne marche pas :
1. Vérifier les logs sur Vercel/Railway
2. Ouvrir la console du navigateur (F12)
3. Vérifier que la clé API est bien configurée

---

## 📝 Checklist de déploiement

- [ ] Compte Vercel/Railway créé
- [ ] Projet uploadé/lié
- [ ] Variable `IDFM_API_KEY` ajoutée
- [ ] Déploiement réussi
- [ ] App testée sur navigateur
- [ ] App testée sur mobile
- [ ] Installation PWA testée

✅ Si tout est coché, c'est bon ! 🎉
